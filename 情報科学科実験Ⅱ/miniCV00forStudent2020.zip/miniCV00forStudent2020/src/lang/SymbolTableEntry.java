package lang;

// 記号表へ登録するための一要素
public abstract class SymbolTableEntry {
	// 要素を表示するためのもの
	public abstract String toExplainString();
}
