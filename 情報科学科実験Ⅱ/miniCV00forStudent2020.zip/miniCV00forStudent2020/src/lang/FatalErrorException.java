package lang;

@SuppressWarnings("serial")
public class FatalErrorException extends Exception {}
