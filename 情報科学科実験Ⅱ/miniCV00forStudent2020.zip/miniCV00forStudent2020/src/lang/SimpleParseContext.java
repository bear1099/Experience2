package lang;

public class SimpleParseContext extends ParseContext {

	public SimpleParseContext(IOContext ioCtx, SimpleTokenizer tknz) {
		super(ioCtx, tknz);
	}
}