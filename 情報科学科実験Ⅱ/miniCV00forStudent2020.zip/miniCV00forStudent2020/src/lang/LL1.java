package lang;

public interface LL1<Tkn> {
// インタフェースに static とは書けないのでコメントアウトしてあるが、そういうメソッドを忘れずに実装して欲しい
//	public abstract static boolean isFirst(Tkn tk);
}
